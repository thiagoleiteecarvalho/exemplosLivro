﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Consulta
    {
        public int codigo { get; set; }

        public Paciente paciente { get; set; }

        public Medico medico { get; set; }

        public DateTime data { get; set; }

        public Consulta()
        {

        }

        public override int GetHashCode()
        {

            int prime = 11;
            int result = 23;
            result = prime * result + ((data == null) ? 0 : data.GetHashCode());
            result = prime * result
                    + ((paciente == null) ? 0 : paciente.GetHashCode());
            result = prime * result + ((medico == null) ? 0 : medico.GetHashCode());
            return result;
        }

        public override bool Equals(Object obj)
        {

            if (obj is Consulta) {

                Consulta consulta = obj as Consulta;

                return this.data.Equals(consulta.data)
                        && this.paciente.Equals(consulta.paciente)
                            && this.medico.Equals(consulta.medico);
            }
            return false;
        }

        public override String ToString()
        {
            return "Paciente : " + this.paciente.nome + " Médico: " + this.medico.nome + " Data: " + this.data.ToString("dd/MM/yyyy");
        }
    }
}
