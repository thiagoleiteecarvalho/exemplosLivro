﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Medico : Pessoa
    {

        private int crm;

        private List<Especialidade> especialidades;

        private double valorHora;

        public Medico()
        {

        }

        public int Crm
        {
            set { crm = value; }
            get { return crm; }
        } 

        public List<Especialidade> Especialidades
        {
            set { especialidades = value; }
            get { return especialidades; }
        }

        public double ValorHora
        {
            set { valorHora = value; }
            get { return valorHora; }
        }

        public override int GetHashCode()
        {
            int prime = 5;
            int result = 7;
            result = prime * result + ((nome == null) ? 0 : nome.GetHashCode());
            return result;
        }

        public override bool Equals(Object obj)
        {

            if (obj is Medico) {

                Medico medico = obj as Medico;
                return crm.Equals(medico.Crm);
            }
            return false;
        }

        public override String ToString()
        {
            return "Nome: " + this.nome;
        }
    }
}
