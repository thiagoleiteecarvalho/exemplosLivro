﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Paciente : Pessoa
    {
        private String cpf;

        private Plano plano;

        public Paciente()
        {

        }

        public String Cpf
        {
            set { cpf = value; }
            get { return cpf; }
        }

        public Plano Plano
        {
            set { plano = value; }
            get { return plano; }
        }

        public override int GetHashCode()
        {

            int prime = 17;
            int result = 3;
            result = prime * result + ((cpf == null) ? 0 : cpf.GetHashCode());
            return result;
        }

        public override bool Equals(Object obj)
        {

            if (obj is Paciente) {

                Paciente paciente = obj as Paciente;
                return this.cpf.Equals(paciente.Cpf);
            }
            return false;
        }

        public override String ToString()
        {
            return "Nome: " + nome + " CPF: " + this.cpf;
        }
    }
}
