﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Pessoa
    {
        public String nome { get; set; }

        public DateTime dataNascimento { get; set; }

        public Endereco endereco { get; set; }

        public Pessoa()
        {

        }
    }
}
