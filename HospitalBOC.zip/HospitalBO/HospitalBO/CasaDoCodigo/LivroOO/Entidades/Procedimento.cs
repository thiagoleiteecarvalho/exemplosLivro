﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public abstract class Procedimento
    {
        public int codigo { get; set; }

        public Paciente paciente { get; set; }

        public List<Medico> medicos { get; set; }

        public DateTime data { get; set; }

        public Sala sala { get; set; }

        public double valor { get; set; }

        public int tempoDuracao { get; set; }

        public Procedimento()
        {

        }
    }
}
