﻿using CasaDoCodigo.LivroOO.Entidades;
using CasaDoCodigo.LivroOO.Persistencia;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Negocio
{
    public class ConsultaNegocio
    {
        private ConsultaBancoDeDados bancoDeDados;

        public ConsultaNegocio()
        {
            this.bancoDeDados = new ConsultaBancoDeDados();
        }

        public void Marcar(Paciente paciente, Medico medico, DateTime data)
        {

            Consulta consulta = new Consulta();
            consulta.paciente = paciente;
            consulta.medico = medico;
            consulta.data = data;

            bancoDeDados.Adicionar(consulta);
        }

        public void Cancelar(Consulta consulta)
        {
            bancoDeDados.Excluir(consulta);
        }

        public Consulta Consultar(int codigo)
        {

            ReadOnlyCollection<Consulta> consultas = bancoDeDados.ListarTodos();

            foreach (Consulta consulta in consultas)
            {
                if (consulta.codigo == codigo)
                {
                    return consulta;
                }
            }
            return null;
        }

        public List<Consulta> PesquisarPorPaciente(Paciente paciente)
        {

            ReadOnlyCollection<Consulta> consultas = bancoDeDados.ListarTodos();

            List<Consulta> consultasDoPaciente = new List<Consulta>();
            foreach (Consulta consulta in consultas)
            {
                if (consulta.paciente.Equals(paciente))
                {
                    consultasDoPaciente.Add(consulta);
                }
            }

            return consultasDoPaciente;
        }

        public ReadOnlyCollection<Consulta> ListarTodos()
        {
            return bancoDeDados.ListarTodos();
        }
    }
}
