﻿using CasaDoCodigo.LivroOO.Entidades;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Negocio
{
    public class FaringoplastiaNegocio :ProcedimentoNegocio
    {
        public override void Marcar(List<Medico> medicos, Paciente paciente, DateTime data)
        {

            Faringoplastia faringoplastia = new Faringoplastia();
            faringoplastia.paciente = paciente;
            faringoplastia.medicos = medicos;
            faringoplastia.data = data;

            BancoDeDados.Adicionar(faringoplastia);
        }

        public Faringoplastia Consultar(int codigo)
        {

            ReadOnlyCollection<Procedimento> procedimentos = BancoDeDados.ListarTodos();

            foreach (Procedimento procedimento in procedimentos)
            {

                if (procedimento.codigo == codigo)
                {
                    return (Faringoplastia)procedimento;
                }
            }

            return null;
        }

        public List<Faringoplastia> PesquisarPorMedico(Medico medico)
        {

            ReadOnlyCollection<Procedimento> procedimentos = BancoDeDados.ListarTodos();

            List<Faringoplastia> procedimentosDoMedico = new List<Faringoplastia>();
            foreach (Procedimento procedimento in procedimentos)
            {
                if (procedimento.medicos.Contains(medico) && procedimento is Faringoplastia)
                {
                    procedimentosDoMedico.Add((Faringoplastia)procedimento);
                }
            }
		
		    return procedimentosDoMedico;
	    }

        public ReadOnlyCollection<Faringoplastia> ListarTodos()
        {

            ReadOnlyCollection<Procedimento> procedimentos = BancoDeDados.ListarTodos();

            List<Faringoplastia> faringoplastias = new List<Faringoplastia>();

            foreach (Procedimento procedimento in procedimentos)
            {

                if (procedimento is Faringoplastia)
                {
                    faringoplastias.Add((Faringoplastia)procedimento);
                }
            }

            return faringoplastias.AsReadOnly();
        }

        public override double CalcularTotal(Procedimento procedimento)
        {
            double valorCliente = procedimento.paciente.Plano.Mensalidade * 0.25;

            double totalMedicos = 0.0;
            foreach (Medico medico in procedimento.medicos)
            {
                totalMedicos += medico.ValorHora;
            }

            return valorCliente + procedimento.valor + totalMedicos;
        }
    }
}
