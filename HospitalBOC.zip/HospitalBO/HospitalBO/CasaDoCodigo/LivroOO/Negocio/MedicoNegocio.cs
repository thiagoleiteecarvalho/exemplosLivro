﻿using CasaDoCodigo.LivroOO.Entidades;
using CasaDoCodigo.LivroOO.Persistencia;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Negocio
{
    public class MedicoNegocio
    {
        private MedicoBancoDeDados bancoDeDados;

        public MedicoNegocio()
        {
            this.bancoDeDados = new MedicoBancoDeDados();
        }

        public void Cadastrar(Medico medico)
        {
            bancoDeDados.Adicionar(medico);
        }

        public void Alterar(Medico medico)
        {
            bancoDeDados.Alterar(medico);
        }

        public void Excluir(Medico medico)
        {
            bancoDeDados.Excluir(medico);
        }

        public Medico Consultar(int crm)
        {

            Medico medico = new Medico();
            medico.Crm = crm;

            ReadOnlyCollection<Medico> medicos = bancoDeDados.ListarTodos();

            foreach (Medico med in medicos)
            {
                if (med.Equals(medico))
                {
                    return med;
                }
            }

            return null;
        }

        public List<Medico> Consultar(String nome)
        {

            ReadOnlyCollection<Medico> medicos = bancoDeDados.ListarTodos();

            List<Medico> medicosSelecionados = new List<Medico>();
            foreach (Medico med in medicos)
            {
                if (med.nome.StartsWith(nome))
                {
                    medicosSelecionados.Add(med);
                }
            }

            return medicosSelecionados;
        }

        public ReadOnlyCollection<Medico> ListarTodos()
        {
            return bancoDeDados.ListarTodos();
        }
    }
}
