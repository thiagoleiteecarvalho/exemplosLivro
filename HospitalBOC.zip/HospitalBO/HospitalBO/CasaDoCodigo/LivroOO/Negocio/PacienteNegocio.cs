﻿using CasaDoCodigo.LivroOO.Entidades;
using CasaDoCodigo.LivroOO.Persistencia;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Negocio
{
    public class PacienteNegocio
    {
        private PacienteBancoDeDados bancoDeDados;

        public PacienteNegocio()
        {
            this.bancoDeDados = new PacienteBancoDeDados();
        }

        public void Cadastrar(Paciente paciente)
        {
            bancoDeDados.Adicionar(paciente);
        }

        public void Alterar(Paciente paciente)
        {
            bancoDeDados.Alterar(paciente);
        }

        public void Excluir(Paciente paciente)
        {
            bancoDeDados.Excluir(paciente);
        }

        public Paciente Consultar(String cpf)
        {

            Paciente paciente = new Paciente();
            paciente.Cpf = cpf;

            ReadOnlyCollection<Paciente> pacientes = bancoDeDados.ListarTodos();

            foreach (Paciente pac in pacientes)
            {
                if (pac.Equals(paciente))
                {
                    return pac;
                }
            }

            return null;
        }

        public List<Paciente> Consultar(String nome, DateTime dataNascimento)
        {

            ReadOnlyCollection<Paciente> pacientes = bancoDeDados.ListarTodos();

            List<Paciente> pacientesSelecionados = new List<Paciente>();
            foreach (Paciente pac in pacientes)
            {
                if (pac.nome.StartsWith(nome)
                        && DateTime.Equals(pac.dataNascimento, dataNascimento))
                {
                    pacientesSelecionados.Add(pac);
                }
            }

            return pacientesSelecionados;
        }

        public ReadOnlyCollection<Paciente> ListarTodos()
        {
            return bancoDeDados.ListarTodos();
        }
    }
}
