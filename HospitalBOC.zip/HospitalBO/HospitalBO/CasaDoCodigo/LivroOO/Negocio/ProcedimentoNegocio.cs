﻿using CasaDoCodigo.LivroOO.Entidades;
using CasaDoCodigo.LivroOO.Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Negocio
{
    public abstract class ProcedimentoNegocio
    {
        private ProcedimentoBancoDeDados bancoDeDados;

        public ProcedimentoNegocio()
        {
            this.bancoDeDados = new ProcedimentoBancoDeDados();
        }

        public ProcedimentoBancoDeDados BancoDeDados 
        {
            get { return bancoDeDados; }
        }

        public void Cancelar(Procedimento procedimento)
        {
            bancoDeDados.Excluir(procedimento);
        }

        public abstract void Marcar(List<Medico> medico, Paciente paciente, DateTime data);

        public abstract double CalcularTotal(Procedimento procedimento);
    }
}
