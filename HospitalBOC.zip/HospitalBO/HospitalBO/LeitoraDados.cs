﻿using CasaDoCodigo.LivroOO.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Util
{
    public class LeitoraDados
    {

        public LeitoraDados()
        {

        }

        public String LerTexto()
        {
            String texto = Console.ReadLine();

            return texto;
        }

        public Paciente LerNovoPaciente()
        {

            Paciente paciente = new Paciente();
            Console.WriteLine("Digite o CPF: ");
            String cpf = Console.ReadLine();
            paciente.Cpf = cpf;

            Console.WriteLine("Digite o nome: ");
            String nome = Console.ReadLine();
            paciente.nome = nome;

            Console.WriteLine("Digite o endereço:(separado por virgula sem espaço entre virgula. Ex: Rua 1 2 3 de oliveira 4,n 20,centro,60529837)");
            String endereco = Console.ReadLine();
            paciente.endereco = ConversorEndereco.ConverterEndereco(endereco);

            Console.WriteLine("Digite a data de nascimento(dd/mm/aaaa): ");
            String data = Console.ReadLine();
            paciente.dataNascimento = ConversoraData.ConverterData(data);

            Console.WriteLine("Digite o nome do plano e sua mensalidade separados por virgula(valores separador por .): ");
            String plano = Console.ReadLine();
            Plano plan = new Plano();
            plan.Nome = plano.Split(',')[0];
            plan.Mensalidade = Double.Parse(plano.Split(',')[1]);
            paciente.Plano = plan;

            return paciente;
        }

        public Paciente LerPacienteAlteracao(String cpf)
        {

            Paciente paciente = new Paciente();
            paciente.Cpf = cpf;

            Console.WriteLine("Digite o nome: ");
            String nome = Console.ReadLine();
            paciente.nome = nome;

            Console.WriteLine("Digite o endereço:(separado por virgula. Ex: Rua 1 2 3 de oliveira 4, n 20, centro, 60529837)");
            String endereco = Console.ReadLine();
            paciente.endereco = ConversorEndereco.ConverterEndereco(endereco);

            return paciente;
        }

        public Paciente NomeDataPaciente()
        {

            Paciente paciente = new Paciente();

            Console.WriteLine("Digite o nome: ");
            String nome = Console.ReadLine();
            paciente.nome = nome;

            Console.WriteLine("Digite a data de nascimento(dd/mm/aaaa): ");
            String data = Console.ReadLine();
            paciente.dataNascimento = ConversoraData.ConverterData(data);

            return paciente;
        }

        public Medico LerNovoMedico()
        {

            Medico medico = new Medico();
            Console.WriteLine("Digite o CRM: ");
            String crm = Console.ReadLine();
            medico.Crm = Int32.Parse(crm);

            Console.WriteLine("Digite o nome: ");
            String nome = Console.ReadLine();
            medico.nome = nome;

            Console.WriteLine("Digite o endereço:(separado por virgula sem espaço entre virgula. Ex: Rua 1 2 3 de oliveira 4,n 20,centro,60529837)");
            String endereco = Console.ReadLine();
            medico.endereco = ConversorEndereco.ConverterEndereco(endereco);

            Console.WriteLine("Digite a data de nascimento(dd/mm/aaaa): ");
            String data = Console.ReadLine();
            medico.dataNascimento = ConversoraData.ConverterData(data);

            Console.WriteLine("Digite o valor da hora(separado por ponto): ");
            String valor = Console.ReadLine();
            medico.ValorHora = Double.Parse(valor);

            Console.WriteLine("Digite até 3 especialidades(somente o nome e separadas por virgula): ");
            String especialidades = Console.ReadLine();
            medico.Especialidades = ConversoraEspecialidade.ConverterEspecialidades(especialidades);

            return medico;
        }

        public Medico LerMedicoAlteracao(String crm)
        {

            Medico medico = new Medico();
            medico.Crm = Int32.Parse(crm);

            Console.WriteLine("Digite o nome: ");
            String nome = Console.ReadLine();
            medico.nome = nome;

            Console.WriteLine("Digite o endereço:(separado por virgula. Ex: Rua 1 2 3 de oliveira 4, n 20, centro, 60529837)");
            String endereco = Console.ReadLine();
            medico.endereco = ConversorEndereco.ConverterEndereco(endereco);

            Console.WriteLine("Digite o valor da hora(separado por ponto): ");
            String valor = Console.ReadLine();
            medico.ValorHora = Double.Parse(valor);

            return medico;
        }
    }
}
