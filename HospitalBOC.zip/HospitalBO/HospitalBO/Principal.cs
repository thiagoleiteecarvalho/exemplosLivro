﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CasaDoCodigo.LivroOO.Util;
using CasaDoCodigo.LivroOO.Entidades;
using CasaDoCodigo.LivroOO.Negocio;
using System.Collections.ObjectModel;
using CasaDoCodigo.LivroOO.IntegracaoMinisterio;

namespace CasaDoCodigo.LivroOO.RodarAplicacao
{
    public class Principal
    {

        public static void Main(string[] args)
        {
            Console.WriteLine("Bem vindo ao Sistema Hospitalar!");
            Console.WriteLine("\n");

            PacienteNegocio pacienteNegocio = new PacienteNegocio();
            MedicoNegocio medicoNegocio = new MedicoNegocio();
            ConsultaNegocio consultaNegocio = new ConsultaNegocio();
            FaringoplastiaNegocio faringoplastiaNegocio = new FaringoplastiaNegocio();
            NeurocirurgiaNegocio neurocirurgiaNegocio = new NeurocirurgiaNegocio();
            DemonstrativoMinisterio demonstrativoMinisterio = new DemonstrativoMinisterio();

            LeitoraDados leitoraDados = new LeitoraDados();
            ExibidoraDados exibidoraDados = new ExibidoraDados();

            String opcao = "";

            while (!opcao.Equals("22"))
            {

                Console.WriteLine("Selecione um número:");
                Console.WriteLine("1 - Cadastrar paciente");
                Console.WriteLine("2 - Alterar paciente");
                Console.WriteLine("3 - Excluir paciente");
                Console.WriteLine("4 - Consultar paciente pelo CPF");
                Console.WriteLine("5 - Consultar paciente por nome e data de nascimento");
                Console.WriteLine("6 - Listar pacientes");

                Console.WriteLine("7 - Cadastar médico");
                Console.WriteLine("8 - Alterar médico");
                Console.WriteLine("9 - Excluir médico");
                Console.WriteLine("10 - Consultar médico por CRM");
                Console.WriteLine("11 - Consular médico por nome");
                Console.WriteLine("12 - Listar médicos");

                Console.WriteLine("13 - Marcar consulta");
                Console.WriteLine("14 - Cancelar consulta");
                Console.WriteLine("15 - Pesquisar consulta por paciente");
                Console.WriteLine("16 - Listar consultas");

                Console.WriteLine("17 - Marcar procedimento");
                Console.WriteLine("18 - Cancelar procedimento");
                Console.WriteLine("19 - Pesquisar procedimento por médico");
                Console.WriteLine("20 - Listar procedimentos");

                Console.WriteLine("21 - Gerar Demonstrativo Ministério");

                Console.WriteLine("22 - Sair");

                opcao = leitoraDados.LerTexto();

                switch (opcao)
                {
                    case "1":
                        Paciente novoPaciente = leitoraDados.LerNovoPaciente();
                        pacienteNegocio.Cadastrar(novoPaciente);
                        break;
                    case "2":
                        Console.WriteLine("Digite o CPF  do Paciente a ser alterado:");
                        String cpfAlterar = leitoraDados.LerTexto();
                        Paciente pacienteAlterar = pacienteNegocio.Consultar(cpfAlterar);
                        exibidoraDados.ExibirPaciente(pacienteAlterar);
                        Console.WriteLine("Deseja realmente alterar? S/N");
                        String alterar = leitoraDados.LerTexto();
                        if ("S".Equals(alterar, StringComparison.InvariantCultureIgnoreCase))
                        {

                            Paciente pacienteAlterado = leitoraDados.LerPacienteAlteracao(cpfAlterar);
                            pacienteNegocio.Alterar(pacienteAlterado);
                        }
                        break;
                    case "3":
                        Console.WriteLine("Digite o CPF do Paciente a ser excluido:");
                        String cpfExcluir = leitoraDados.LerTexto();
                        Paciente pacienteExcluir = pacienteNegocio.Consultar(cpfExcluir);
                        pacienteNegocio.Excluir(pacienteExcluir);
                        break;
                    case "4":
                        Console.WriteLine("Digite o CPF  do Paciente:");
                        String cpfConsultar = leitoraDados.LerTexto();
                        Paciente pacienteConsultar = pacienteNegocio.Consultar(cpfConsultar);
                        exibidoraDados.ExibirPaciente(pacienteConsultar);
                        break;
                    case "5":
                        Paciente paciente = leitoraDados.NomeDataPaciente();
                        List<Paciente> pacientes = pacienteNegocio.Consultar(paciente.nome, paciente.dataNascimento);
                        exibidoraDados.ExibirPacientes(pacientes);
                        break;
                    case "6":
                        ReadOnlyCollection<Paciente> pacientesListagem = pacienteNegocio.ListarTodos();
                        exibidoraDados.ExibirPacientes(pacientesListagem);
                        break;
                    case "7":
                        Medico novoMedico = leitoraDados.LerNovoMedico();
                        medicoNegocio.Cadastrar(novoMedico);
                        break;
                    case "8":
                        Console.WriteLine("Digite o CRM  do médico a ser alterado:");
                        String crmAlterar = leitoraDados.LerTexto();
                        Medico medicoAlterar = medicoNegocio.Consultar(Int32.Parse(crmAlterar));
                        exibidoraDados.ExibirMedico(medicoAlterar);
                        Console.WriteLine("Deseja realmente alterar? S/N");
                        alterar = leitoraDados.LerTexto();
                        if ("S".Equals(alterar, StringComparison.InvariantCultureIgnoreCase))
                        {

                            Medico medicoAlterado = leitoraDados.LerMedicoAlteracao(crmAlterar);
                            medicoNegocio.Alterar(medicoAlterado);
                        }
                        break;
                    case "9":
                        Console.WriteLine("Digite o CRM do Médico a ser excluido:");
                        String crmExcluir = leitoraDados.LerTexto();
                        Medico medicoExcluir = medicoNegocio.Consultar(Int32.Parse(crmExcluir));
                        medicoNegocio.Excluir(medicoExcluir);
                        break;
                    case "10":
                        Console.WriteLine("Digite o CRM  do Médico:");
                        String crmConsultar = leitoraDados.LerTexto();
                        Medico medicoConsultar = medicoNegocio.Consultar(Int32.Parse(crmConsultar));
                        exibidoraDados.ExibirMedico(medicoConsultar);
                        break;
                    case "11":
                        Console.WriteLine("Digite o nome do Médico:");
                        String nome = leitoraDados.LerTexto();
                        List<Medico> medicos = medicoNegocio.Consultar(nome);
                        exibidoraDados.ExibirMedicos(medicos);
                        break;
                    case "12":
                        ReadOnlyCollection<Medico> medicosListagem = medicoNegocio.ListarTodos();
                        exibidoraDados.ExibirMedicos(medicosListagem);
                        break;
                    case "13":
                        Console.WriteLine("Digite o CRM  do Médico:");
                        String crmConsulta = leitoraDados.LerTexto();
                        Console.WriteLine("Digite o CPF  do Paciente:");
                        String cpfConsulta = leitoraDados.LerTexto();
                        Medico medicoConsulta = medicoNegocio.Consultar(Int32.Parse(crmConsulta));
                        Paciente pacienteConsulta = pacienteNegocio.Consultar(cpfConsulta);
                        Console.WriteLine("Digite a data da consulta(dd/mm/aaaa): ");
                        String dataConsulta = leitoraDados.LerTexto();
                        consultaNegocio.Marcar(pacienteConsulta, medicoConsulta, ConversoraData.ConverterData(dataConsulta));
                        break;
                    case "14":
                        Console.WriteLine("Digite o código da consulta:");
                        String codigoConsulta = leitoraDados.LerTexto();
                        Consulta consultaDesmarcar = consultaNegocio.Consultar(Int32.Parse((codigoConsulta)));
                        exibidoraDados.ExibirConsulta(consultaDesmarcar);
                        Console.WriteLine("Deseja realmente desmarcar? S/N");
                        String desmarcar = leitoraDados.LerTexto();
                        if ("S".Equals(desmarcar, StringComparison.InvariantCultureIgnoreCase))
                        {
                            consultaNegocio.Cancelar(consultaDesmarcar);
                        }
                        break;
                    case "15":
                        Console.WriteLine("Digite o CPF do paciente da consulta:");
                        String cpfPacienteConsulta = leitoraDados.LerTexto();
                        Paciente pacConsulta = new Paciente();
                        pacConsulta.Cpf = cpfPacienteConsulta;
                        List<Consulta> consultasListagemPesquisa = consultaNegocio.PesquisarPorPaciente(pacConsulta);
                        exibidoraDados.ExibirConsultas(consultasListagemPesquisa);
                        break;
                    case "16":
                        ReadOnlyCollection<Consulta> consultasListagem = consultaNegocio.ListarTodos();
                        exibidoraDados.ExibirConsultas(consultasListagem);
                        break;
                    case "17":
                        Console.WriteLine("Digite o CRM de 2 Médicos(separado por vírgula):");
                        String crmProcedimento = leitoraDados.LerTexto();
                        Console.WriteLine("Digite o CPF  do Paciente:");
                        String cpfProcedimento = leitoraDados.LerTexto();

                        String[] crms = crmProcedimento.Split(',');
                        List<Medico> medicosProcedimento = new List<Medico>();
                        foreach (String crm in crms)
                        {

                            Medico medicoProcedimento = medicoNegocio.Consultar(Int32.Parse(crm));
                            medicosProcedimento.Add(medicoProcedimento);
                        }
                        Paciente pacienteProcedimento = pacienteNegocio.Consultar(cpfProcedimento);
                        Console.WriteLine("Digite a data do procedimento(dd/mm/aaaa): ");
                        String dataProcedimento = leitoraDados.LerTexto();
                        Console.WriteLine("Digite N para Neurologia e F para Faringoplastia: ");
                        String procedimento = leitoraDados.LerTexto();
                        if ("F".Equals(procedimento, StringComparison.InvariantCultureIgnoreCase))
                        {
                            faringoplastiaNegocio.Marcar(medicosProcedimento, pacienteProcedimento, ConversoraData.ConverterData(dataProcedimento));
                        }
                        else
                        {
                            neurocirurgiaNegocio.Marcar(medicosProcedimento, pacienteProcedimento, ConversoraData.ConverterData(dataProcedimento));
                        }
                        break;
                    case "18":
                        Console.WriteLine("Digite o código do procedimento e N para Neurologia e F para Faringoplastia(separado por virgula) para cancelar:");
                        String entrada = leitoraDados.LerTexto();
                        String codigo = entrada.Split(',')[0];
                        String tipo = entrada.Split(',')[1];
                        if ("F".Equals(tipo, StringComparison.InvariantCultureIgnoreCase))
                        {

                            Faringoplastia faringoplastia = faringoplastiaNegocio.Consultar(Int32.Parse(codigo));

                            exibidoraDados.ExibirFaringoplastia(faringoplastia);
                            Console.WriteLine("Deseja realmente desmarcar? S/N");
                            String desmarcarFaringoplastia = leitoraDados.LerTexto();
                            if ("S".Equals(desmarcarFaringoplastia, StringComparison.InvariantCultureIgnoreCase))
                            {
                                faringoplastiaNegocio.Cancelar(faringoplastia);
                            }
                        }
                        else
                        {

                            Neurocirurgia neurocirurgia = neurocirurgiaNegocio.Consultar(Int32.Parse(codigo));

                            exibidoraDados.ExibirNeurocirurgia(neurocirurgia);
                            Console.WriteLine("Deseja realmente desmarcar? S/N");
                            String desmarcarNeurocirurgia = leitoraDados.LerTexto();
                            if ("S".Equals(desmarcarNeurocirurgia, StringComparison.InvariantCultureIgnoreCase))
                            {
                                neurocirurgiaNegocio.Cancelar(neurocirurgia);
                            }
                        }
                        break;
                    case "19":
                        Console.WriteLine("Digite o CRM dos Médicos(separado por vírgula):");
                        String crmsMedicos = leitoraDados.LerTexto();
                        String[] crmsProcedimentos = crmsMedicos.Split(',');

                        List<Procedimento> procedimentos = new List<Procedimento>();
                        foreach (String crm in crmsProcedimentos)
                        {
                            Medico medico = medicoNegocio.Consultar(Int32.Parse(crm));
                            procedimentos.AddRange(faringoplastiaNegocio.PesquisarPorMedico(medico));
                            procedimentos.AddRange(neurocirurgiaNegocio.PesquisarPorMedico(medico));
                        }
                        exibidoraDados.ExibirProcedimentos(procedimentos);
                        break;
                    case "20":
                        List<Procedimento> procedimentosListagem = new List<Procedimento>();
                        procedimentosListagem.AddRange(faringoplastiaNegocio.ListarTodos());
                        procedimentosListagem.AddRange(neurocirurgiaNegocio.ListarTodos());
                        exibidoraDados.ExibirProcedimentos(procedimentosListagem);
                        break;
                    case "21":
                        List<Procedimento> procedimentosDemonstrativo = new List<Procedimento>();
                        procedimentosDemonstrativo.AddRange(faringoplastiaNegocio.ListarTodos());
                        procedimentosDemonstrativo.AddRange(neurocirurgiaNegocio.ListarTodos());
                        demonstrativoMinisterio.gerarDados(procedimentosDemonstrativo);
                        break;
                    default:
                        Console.WriteLine("Volte sempre!");
                        Environment.Exit(0);
                        break;
                }

            }
        }
    }
}
