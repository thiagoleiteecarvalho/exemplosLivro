package br.com.casaDoCodigo.livroOO.entidades;

public class Faringoplastia extends Procedimento {

}
