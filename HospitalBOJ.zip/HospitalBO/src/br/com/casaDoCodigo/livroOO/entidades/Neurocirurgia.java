package br.com.casaDoCodigo.livroOO.entidades;

public class Neurocirurgia extends Procedimento {

}
