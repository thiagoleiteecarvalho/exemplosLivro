﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Especialidade
    {
        private String nome;

        public String Nome
        {
            set { nome = value; }
            get { return nome; }
        }

        public Especialidade()
        {

        }
    }
}
