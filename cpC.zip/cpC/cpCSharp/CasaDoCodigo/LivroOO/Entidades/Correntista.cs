﻿using System;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Correntista
    {
        public String Nome { get; set; }

        public Correntista()
        {

        }

        public override int GetHashCode()
        {

            const int primo = 31;
            int resultado = 1;

            resultado = primo * resultado + ((Nome == null) ? 0 : Nome.GetHashCode());

            return resultado;
        }

        public override bool Equals(Object obj)
        {

            if (obj is Correntista)
            {
                Correntista correntista = obj as Correntista;

                return this.Nome.Equals(correntista.Nome, StringComparison.InvariantCultureIgnoreCase);
            }
            return false;
        }

        public override String ToString()
        {
            return "Correntista: " + this.Nome;
        }
    }
}