﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public sealed class OperacaoDeposito : Operacao
    {
		public override void Processar()
			{

				Decimal saldo = new Decimal(Decimal.ToInt32(ContaDestino.Saldo));
				Decimal novoSaldo = Decimal.Add(saldo, Valor);

				ContaDestino.Saldo = novoSaldo;
			}
		}
}
