﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class OperacaoTransferencia : Operacao
    {
		public override void Processar()
			{

				Decimal saldo = new Decimal(Decimal.ToInt32(ContaDestino.Saldo));
				Decimal novoSaldo = Decimal.Add(saldo, Valor);
				ContaDestino.Saldo = novoSaldo;

				ContaOrigem.Saldo = Decimal.Subtract(ContaOrigem.Saldo, Valor);
			}
		}
}
