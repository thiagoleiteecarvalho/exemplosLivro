﻿using System;
using System.Collections.Generic;
using CasaDoCodigo.LivroOO.Entidades;


namespace CasaDoCodigo.LivroOO.Main
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
			//Depósito
			Operacao deposito = new OperacaoDeposito();

			Conta contaDestinoDeposito = new Conta();
			contaDestinoDeposito.Numero = 15698;
			contaDestinoDeposito.Digito = 2;
			contaDestinoDeposito.Saldo = new Decimal(30);
			Correntista correntistaDeposito = new Correntista();
			correntistaDeposito.Nome = "Fulano";
			contaDestinoDeposito.Correntista = correntistaDeposito;

			deposito.ContaDestino = contaDestinoDeposito;
			deposito.ContaOrigem = null;
			deposito.Valor = new Decimal(20);

			//Transferência
			Operacao transferencia = new OperacaoTransferencia();

			Conta contaDestinoTransferencia = new Conta();
			contaDestinoTransferencia.Numero = 15698;
			contaDestinoTransferencia.Digito = 2;
			contaDestinoTransferencia.Saldo = new Decimal(40);
			Correntista correntistaDestinoTransferencia = new Correntista();
			correntistaDestinoTransferencia.Nome = "Cicrano";
			contaDestinoTransferencia.Correntista = correntistaDestinoTransferencia;

			transferencia.ContaDestino = contaDestinoTransferencia;
			transferencia.Valor = new Decimal(30);

			Conta contaOrigemTransferencia = new Conta();
			contaOrigemTransferencia.Numero = 75335;
			contaOrigemTransferencia.Digito = 8;
			contaOrigemTransferencia.Saldo = new Decimal(90);
			Correntista correntistaOrigemTransferencia = new Correntista();
			correntistaOrigemTransferencia.Nome = "Beltrano";
			contaOrigemTransferencia.Correntista = correntistaOrigemTransferencia;

			transferencia.ContaOrigem = contaOrigemTransferencia;


			// Processamento
			List<Operacao> operacoes = new List<Operacao>();

			operacoes.Add(deposito);
			operacoes.Add(transferencia);

			//Antes de processar
			Console.WriteLine("Saldo antes do depósito: ");
			Console.WriteLine(contaDestinoDeposito.ToString() + ". Saldo: " + contaDestinoDeposito.Saldo);
			Console.WriteLine("Valor a ser depositado: " + deposito.Valor);

			Console.WriteLine("Saldo antes da transferência: ");
			Console.WriteLine(contaOrigemTransferencia.ToString() + ". Saldo: " + contaOrigemTransferencia.Saldo);
			Console.WriteLine(contaDestinoTransferencia.ToString() + ". Saldo: " + contaDestinoTransferencia.Saldo);
			Console.WriteLine("Valor a ser transferiado: " + transferencia.Valor);
			Console.WriteLine("\n");

			//Processando
			ProcessadoraOperacoes processadoraOperacoes = new ProcessadoraOperacoes();
			processadoraOperacoes.Processar(operacoes);


			//Depois de processar
			Console.WriteLine("Saldo depois do depósito: ");
			Console.WriteLine(contaDestinoDeposito.ToString() + ". Saldo: " + contaDestinoDeposito.Saldo);

			Console.WriteLine("Saldo depois da transferência: ");
			Console.WriteLine(contaOrigemTransferencia.ToString() + ". Saldo: " + contaOrigemTransferencia.Saldo);
			Console.WriteLine(contaDestinoTransferencia.ToString() + ". Saldo: " + contaDestinoTransferencia.Saldo);

			//Tecle enter para finalizar
			Console.ReadLine();
		}
    }
}
