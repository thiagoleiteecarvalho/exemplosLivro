﻿using System;
using System.Collections.Generic;
using CasaDoCodigo.LivroOO.Entidades;

namespace CasaDoCodigo.LivroOO.Main
{
    public class ProcessadoraOperacoes
    {
		public void Processar(List<Operacao> operacoes)
		{

			foreach (Operacao operacao in operacoes)
			{
				operacao.Processar();	
			}
		}
	}
}
