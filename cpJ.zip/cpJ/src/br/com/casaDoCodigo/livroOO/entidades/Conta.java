package br.com.casaDoCodigo.livroOO.entidades;

import java.math.BigDecimal;

public class Conta {

	private long numero;
	
	private int digito;
	
	private BigDecimal saldo;
	
	private Correntista correntista;
	
	public Conta() {
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public int getDigito() {
		return digito;
	}

	public void setDigito(int digito) {
		this.digito = digito;
	}

	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	public Correntista getCorrentista() {
		return correntista;
	}

	public void setCorrentista(Correntista correntista) {
		this.correntista = correntista;
	}

	@Override
	public int hashCode() {
		
		final int primo = 31;
		int resultado = 1;
		
		resultado = primo * resultado + ((correntista == null) ? 0 : correntista.hashCode());
		resultado = primo * resultado + digito;
		resultado = primo * resultado + (int) (numero ^ (numero >>> 32));
		
		return resultado;
	}

	@Override
	public boolean equals(Object obj) {

		if (obj instanceof Conta) {
			
			Conta conta = (Conta) obj;

			if (!correntista.equals(conta.correntista) && digito != conta.digito && numero != conta.numero) {
				return false;
			}
		}
		
		return false;
	}
	
	@Override
	public String toString() {
		return "N�mero: " + this.numero + ". D�gito: " + this.digito + ". " + correntista.toString();
	}	
	
}
