package br.com.casaDoCodigo.livroOO.entidades;

public class Correntista {

	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public int hashCode() {
		
		final int primo = 31;
		int resultado = 1;
		
		resultado = primo * resultado + ((nome == null) ? 0 : nome.hashCode());
		
		return resultado;
	}

	@Override
	public boolean equals(Object obj) {

		if (obj instanceof Correntista) {
			
			Correntista correntista = (Correntista) obj;
			
			if (this.nome.equalsIgnoreCase(correntista.getNome())) {
				return true;
			}
		}

		return false;
	}
	
	@Override
	public String toString() {
		return "Correntista: " + this.nome;
	}
}
