package br.com.casaDoCodigo.livroOO.entidades;

import java.math.BigDecimal;

public abstract class Operacao {

	private Conta contaOrigem;
   
	private Conta contaDestino;
   
	private BigDecimal valor;
   
	public Operacao() {
	}

	public Conta getContaOrigem() {
		return contaOrigem;
	}

	public void setContaOrigem(Conta contaOrigem) {
		this.contaOrigem = contaOrigem;
	}

	public Conta getContaDestino() {
		return contaDestino;
	}

	public void setContaDestino(Conta contaDestino) {
		this.contaDestino = contaDestino;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public abstract void processar();
	
	@Override
	public int hashCode() {
		
		final int primo = 31;
		int resultado = 1;
		
		resultado = primo * resultado + ((contaDestino == null) ? 0 : contaDestino.hashCode());
		resultado = primo * resultado + ((contaOrigem == null) ? 0 : contaOrigem.hashCode());
		
		return resultado;
	}

	@Override
	public boolean equals(Object obj) {

		if (obj instanceof Operacao) {
			
			Operacao operacao = (Operacao) obj;

			if (!contaDestino.equals(operacao.contaDestino) && contaOrigem.equals(operacao.contaOrigem)) {
				return false;
			}
		}
		
		return false;
	}
	
	@Override
	public String toString() {
		return "Conta Destino: " + contaDestino.getNumero() + "-" + contaDestino.getDigito() + ". Conta Origem: "  + contaOrigem.getNumero() + "-" + contaOrigem.getDigito();
	}
}
