package br.com.casaDoCodigo.livroOO.entidades;

import java.math.BigDecimal;

public final class OperacaoTransferencia extends Operacao {

	@Override
	public void processar() {

		BigDecimal saldo = new BigDecimal(getContaDestino().getSaldo().doubleValue());
		BigDecimal novoSaldo = saldo.add(getValor());
		getContaDestino().setSaldo(novoSaldo);

		getContaOrigem().setSaldo(getContaOrigem().getSaldo().subtract(getValor()));
	}
}