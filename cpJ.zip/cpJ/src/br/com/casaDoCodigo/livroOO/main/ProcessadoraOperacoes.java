package br.com.casaDoCodigo.livroOO.main;

import java.util.List;

import br.com.casaDoCodigo.livroOO.entidades.Operacao;

public class ProcessadoraOperacoes {

	public void processar(List<Operacao> operacoes) {

		for(Operacao operacao: operacoes) {
			operacao.processar();
		}		
   }
}