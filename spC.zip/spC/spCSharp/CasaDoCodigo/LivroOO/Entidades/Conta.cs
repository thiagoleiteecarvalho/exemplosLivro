﻿using System;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Conta
    {
        public long Numero { get; set; }

        public int Digito { get; set; }

        public Decimal Saldo { get; set; }

        public Correntista Correntista { get; set; }

        public Conta()
        {

        }

        public override int GetHashCode()
        {

            const int primo = 31;
            int resultado = 1;

            resultado = primo * resultado + ((Correntista == null) ? 0 : Correntista.GetHashCode());
            resultado = primo * resultado + Digito;
            resultado = primo * resultado + (int)(Numero ^ ((uint)Numero >> 32));

            return resultado;
        }

        public override bool Equals(Object obj)
        {

            if (obj is Conta)
            {

                Conta conta = obj as Conta;

                return this.Correntista.Equals(conta.Correntista)
                        && this.Digito == conta.Digito
                            && this.Numero == conta.Numero;
            }
            return false;
        }

        public override String ToString()
        {
            return "Número: " + this.Numero + ". Dígito: " + this.Digito + ". " + Correntista.ToString();
        }
    }
}
