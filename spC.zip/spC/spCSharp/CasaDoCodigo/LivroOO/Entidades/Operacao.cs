﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public class Operacao
    {
        public Conta ContaOrigem { get; set; }

        public Conta ContaDestino { get; set; }

        public TipoOperacao? TipoOperacao { get; set; }

        public Decimal Valor { get; set; }

        public Operacao()
        {

        }

        public override int GetHashCode()
        {

            const int primo = 31;
            int resultado = 1;

            resultado = primo * resultado + ((ContaDestino == null) ? 0 : ContaDestino.GetHashCode());
            resultado = primo * resultado + ((ContaOrigem == null) ? 0 : ContaOrigem.GetHashCode());
            resultado = primo * resultado + ((TipoOperacao == null) ? 0 : TipoOperacao.GetHashCode());

            return resultado; ;
        }

        public override bool Equals(Object obj)
        {

            if (obj is Operacao)
            {

                Operacao operacao = obj as Operacao;

                return this.ContaDestino.Equals(operacao.ContaDestino)
                        && this.ContaOrigem.Equals(operacao.ContaOrigem)
                            && this.TipoOperacao.Equals(operacao.TipoOperacao);
            }
            return false;
        }

        public override String ToString()
        {
            return "Conta Destino: " + ContaDestino.Numero + "-" + ContaDestino.Digito + ". Conta Origem: " + ContaOrigem.Numero + "-" + ContaOrigem.Digito + "Operação: " + TipoOperacao.Value;
        }
    }
}
