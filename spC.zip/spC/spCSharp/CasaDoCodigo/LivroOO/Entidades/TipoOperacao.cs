﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CasaDoCodigo.LivroOO.Entidades
{
    public enum TipoOperacao
    {
        DEPOSITO,
        TRANSFERENCIA
    }
}
