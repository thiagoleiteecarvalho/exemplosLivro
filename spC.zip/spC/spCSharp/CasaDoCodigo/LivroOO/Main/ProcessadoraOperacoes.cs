﻿using System;
using System.Collections.Generic;
using CasaDoCodigo.LivroOO.Entidades;

namespace CasaDoCodigo.LivroOO.Main
{
    public class ProcessadoraOperacoes
    {
		public void Processar(List<Operacao> operacoes)
		{

			foreach (Operacao operacao in operacoes)
			{

				TipoOperacao tipoOperacao = operacao.TipoOperacao.Value;
				Decimal saldo;
				Decimal novoSaldo;

				switch (tipoOperacao)
				{ 
					case TipoOperacao.DEPOSITO:

						saldo = new Decimal(Decimal.ToInt32(operacao.ContaDestino.Saldo));
						novoSaldo = Decimal.Add(operacao.Valor, saldo);
						
						operacao.ContaDestino.Saldo = novoSaldo;
						break;
					case TipoOperacao.TRANSFERENCIA:

						saldo = new Decimal(Decimal.ToInt32(operacao.ContaDestino.Saldo));
						novoSaldo = Decimal.Add(operacao.Valor, saldo);
						operacao.ContaDestino.Saldo = novoSaldo;

						operacao.ContaOrigem.Saldo = Decimal.Subtract(operacao.ContaOrigem.Saldo, operacao.Valor);
						break;
					default:
						throw new ArgumentException("Operação não suportada.");
				}
			}
		}
	}
}
