package br.com.casaDoCodigo.livroOO.entidades;

public enum TipoOperacao {

	DEPOSITO,
	TRANSFERENCIA;
}
