package br.com.casaDoCodigo.livroOO.main;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import br.com.casaDoCodigo.livroOO.entidades.Conta;
import br.com.casaDoCodigo.livroOO.entidades.Correntista;
import br.com.casaDoCodigo.livroOO.entidades.Operacao;
import br.com.casaDoCodigo.livroOO.entidades.TipoOperacao;

public class MainClass {

	public static void main(String[] args) {
		
		//Dep�sito
		Operacao deposito = new Operacao();
		deposito.setTipoOperacao(TipoOperacao.DEPOSITO);
		
		Conta contaDestinoDeposito = new Conta();
		contaDestinoDeposito.setNumero(15698);
		contaDestinoDeposito.setDigito(2);
		contaDestinoDeposito.setSaldo(new BigDecimal(30));
		Correntista correntistaDeposito =new Correntista();
		correntistaDeposito.setNome("Fulano");
		contaDestinoDeposito.setCorrentista(correntistaDeposito);
		
		deposito.setContaDestino(contaDestinoDeposito);
		deposito.setValor(new BigDecimal(20));
		
		deposito.setContaOrigem(null);
			
		//Transfer�ncia
		Operacao transferencia = new Operacao();
		transferencia.setTipoOperacao(TipoOperacao.TRANSFERENCIA);
		
		Conta contaDestinoTransferencia = new Conta();
		contaDestinoTransferencia.setNumero(15698);
		contaDestinoTransferencia.setDigito(2);
		contaDestinoTransferencia.setSaldo(new BigDecimal(40));
		Correntista correntistaDestinoTransferencia = new Correntista();
		correntistaDestinoTransferencia.setNome("Cicrano");
		contaDestinoTransferencia.setCorrentista(correntistaDestinoTransferencia);
		
		transferencia.setContaDestino(contaDestinoTransferencia);
		transferencia.setValor(new BigDecimal(30));
		
		Conta contaOrigemTransferencia = new Conta();
		contaOrigemTransferencia.setNumero(75335);
		contaOrigemTransferencia.setDigito(8);
		contaOrigemTransferencia.setSaldo(new BigDecimal(90));
		Correntista correntistaOrigemTransferencia = new Correntista();
		correntistaOrigemTransferencia.setNome("Beltrano");
		contaOrigemTransferencia.setCorrentista(correntistaOrigemTransferencia);
		
		transferencia.setContaOrigem(contaOrigemTransferencia);
		
		
		// Processamento
		List<Operacao> operacoes = new ArrayList<>();
		
		operacoes.add(deposito);
		operacoes.add(transferencia);
		
		//Antes de processar
		System.out.println("Saldo antes do dep�sito: ");
		System.out.println(contaDestinoDeposito.toString() + ". Saldo: " + contaDestinoDeposito.getSaldo());
		System.out.println("Valor a ser depositado: " + deposito.getValor());

		System.out.println("Saldo antes da transfer�ncia: ");
		System.out.println(contaOrigemTransferencia.toString() + ". Saldo: " + contaOrigemTransferencia.getSaldo());
		System.out.println(contaDestinoTransferencia.toString() + ". Saldo: " + contaDestinoTransferencia.getSaldo());
		System.out.println("Valor a ser transferiado: " + transferencia.getValor());
		System.out.println("\n");
		
		//Processando
		ProcessadoraOperacoes processadoraOperacoes = new ProcessadoraOperacoes();
		processadoraOperacoes.processar(operacoes);

		
		//Depois de processar
		System.out.println("Saldo depois do dep�sito: ");
		System.out.println(contaDestinoDeposito.toString() + ". Saldo: " + contaDestinoDeposito.getSaldo());

		System.out.println("Saldo depois da transfer�ncia: ");
		System.out.println(contaOrigemTransferencia.toString() + ". Saldo: " + contaOrigemTransferencia.getSaldo());
		System.out.println(contaDestinoTransferencia.toString() + ". Saldo: " + contaDestinoTransferencia.getSaldo());
	}
	
}
