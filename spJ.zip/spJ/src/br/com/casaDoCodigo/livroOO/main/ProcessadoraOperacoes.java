package br.com.casaDoCodigo.livroOO.main;

import java.math.BigDecimal;
import java.util.List;

import br.com.casaDoCodigo.livroOO.entidades.Operacao;
import br.com.casaDoCodigo.livroOO.entidades.TipoOperacao;

public class ProcessadoraOperacoes {

	public void processar(List<Operacao> operacoes) {

		for(Operacao operacao: operacoes) {
			   
		      TipoOperacao tipoOperacao = operacao.getTipoOperacao();
		      BigDecimal saldo = null;
		      BigDecimal novoSaldo = null;
		      
		      switch (tipoOperacao) {
		        case DEPOSITO:
		        	
		        	saldo = new BigDecimal(operacao.getContaDestino().getSaldo().doubleValue());
		        	novoSaldo = saldo.add(operacao.getValor());
		        	
		        	operacao.getContaDestino().setSaldo(novoSaldo);
		        break;
		        case TRANSFERENCIA:
		        	
		        	saldo = new BigDecimal(operacao.getContaDestino().getSaldo().doubleValue());
		        	novoSaldo = saldo.add(operacao.getValor());		        	
		        	operacao.getContaDestino().setSaldo(novoSaldo);
		        	
		        	operacao.getContaOrigem().setSaldo(operacao.getContaOrigem().getSaldo().subtract(operacao.getValor()));
		        break;
		        default:
		        	throw new IllegalArgumentException("Opera��o n�o suportada.");
		      }
		   }		
   }
}